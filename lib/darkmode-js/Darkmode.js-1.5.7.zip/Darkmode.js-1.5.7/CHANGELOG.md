# Changelog

## 1.5.7

* Adding role for better accessiblity of the widget

## 1.5.6

* Aria labels added for accessibility to the widget

## 1.5.5

* Fixing bug of visible button even when using programatically without widget

## 1.5.4

* Fixing the bug of overlay breaking when too many clicks are done at the same time by disabling/enabling the button

## 1.5.3

* Putting back the default values of button's color

## 1.5.2

* Putting back `saveInCookies` to `true` in the default settings

## 1.5.1

* Code refactored for better readability

## 1.5.0

* Support server rendered frameworks such as Next.js and Gatsby
